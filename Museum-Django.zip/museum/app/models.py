from django.db import models
from datetime import date  

class Admin(models.Model):
    username= models.CharField(max_length=50,unique=True)
    password= models.CharField(max_length=50,null=False)
class Image(models.Model):
    title = models.CharField(max_length=100,unique=True)
    year = models.DateField(default=date.today().strftime('%Y-%m-%d'))
    artiste = models.CharField(max_length=32,null=False,default='unknown')
    description = models.CharField(max_length=2000)
    image = models.ImageField(upload_to='images/')
# pour l'assistant:
class Keyword(models.Model):
    text = models.CharField(max_length=256,unique=True)
class Value(models.Model):
    text = models.CharField(max_length=256,unique=True)
class Keyword_Value(models.Model):
    keyword = models.ForeignKey('Keyword',on_delete=models.CASCADE)
    value = models.ForeignKey('Value',on_delete=models.CASCADE)
    class Meta:
        unique_together = ('keyword', 'value',)

