from ast import keyword
from cgitb import text
from email.mime import image
from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import redirect
from app.models import *
from random import randint
from datetime import datetime 
from django.db.models import Q
# start() permet de charger quelque données. lorsque on lance http://localhost:8000/start
def start(request):
    admin=Admin(username='admin',password='admin123')
    admin.save()

    a=Admin.objects.get(id=1)
    a.save()
    return redirect('/admin/')
def admin_check_session(request):
    if 'admin' in request.session:
        try:
            admin = Admin.objects.get(password=request.session['admin'])
            if admin:
                return True
        except:
            return False
    return False
def admin_login(request):
    try:
        if request.method == "POST":
            if Admin.objects.get(username=request.POST.get('username'),password=request.POST.get('password')):
                request.session['admin']=request.POST.get('password')
    except:
        pass
    return redirect('/admin/')
def admin_logout(request):
    try:
        del request.session['admin']
    except:
        pass
    return redirect('/admin/')
def admin_panel(request):
    if admin_check_session(request):
        images = Image.objects.all()

        return render(request,
        'administrator/index.html',
        {
        "images" : images 
        
        })
    return render(request,'administrator/login.html',{"page":"admin"})
def admin_add_art(request):
    if admin_check_session(request):
        return render(request,'administrator/ajouter.html')
    return redirect('/admin/')
def admin_assistant(request):
    if admin_check_session(request):
        keywords=Keyword.objects.all()
        values=Value.objects.all()
        relations=Keyword_Value.objects.all()
        return render(
            request,
            'administrator/assistant.html',
            {
                'keywords':keywords,
                'values':values,
                'relations':relations,
            },
            )
    return redirect('/admin/')
def admin_assistant_keywords_add(request):
    if admin_check_session(request):
        try:
            if request.method == "POST" and request.POST.get('keyword')!="":
                key=Keyword(text=request.POST.get('keyword'))
                key.save()
                return redirect('/admin/assistant?option=added')
        except:
            pass
    return redirect('/admin/assistant?option=added&error')
def admin_assistant_values_add(request):
    if admin_check_session(request):
        try:
            if request.method == "POST" and request.POST.get('value')!="":
                val=Value(text=request.POST.get('value'))
                val.save()
                return redirect('/admin/assistant?option=added')
        except:
            pass
    return redirect('/admin/assistant?option=added&error')
def admin_assistant_relations_add(request):
    if admin_check_session(request):
        try:
            if request.method == "POST":
                key=Keyword.objects.get(text=request.POST.get('keyword'))
                val=Value.objects.get(text=request.POST.get('value'))
                rel=Keyword_Value(keyword=key,value=val)
                
                rel.save()
                return redirect('/admin/assistant?option=added')
        except Exception as e:
            print(e)
    return redirect('/admin/assistant?option=added&error')
def admin_assistant_keywords_delete(request,id):
    if admin_check_session(request):
        try:
            key=Keyword.objects.get(id=id)
            key.delete()
            return redirect('/admin/assistant?option=deleted')
        except:
            pass
    return redirect('/admin/assistant?option=deleted&error')
def admin_assistant_values_delete(request,id):
    if admin_check_session(request):
        try:
            val=Value.objects.get(id=id)
            val.delete()
            return redirect('/admin/assistant?option=deleted')
        except:
            pass
    return redirect('/admin/assistant?option=deleted&error')
def admin_assistant_relations_delete(request,id):
    if admin_check_session(request):
        try:
            rel=Keyword_Value.objects.get(id=id)
            rel.delete()
            return redirect('/admin/assistant?option=deleted')
        except Exception as e:
            print(e)
    return redirect('/admin/assistant?option=deleted&error')


def getAssistantData(request,username,password):
    try:
        admin = Admin.objects.get(username=username,password=password)
        if admin:
            data={}
            keywords=Keyword.objects.all()
            for key in keywords:
                l=[pair.value.text for pair in Keyword_Value.objects.filter(keyword=key)]
                if l:
                    data[key.text]=l
        return HttpResponse(str(data))  
    except:
        return HttpResponse('error')
def getImagesData(request,username,password):
    try:
        admin = Admin.objects.get(username=username,password=password)
        if admin:
            data=[]
            images=Image.objects.all()
            for img in images:
                data.append({"title":img.title.replace('"',' ').replace("'",' '),'year':str(img.year),'artiste':img.artiste.replace('"',' ').replace("'",' '),'description':img.description.replace('"',' ').replace("'",' '),'path':img.image.url})
            if data:
                return HttpResponse(str({"images":data}).replace("'",'"'))
    except:
        return HttpResponse('error')

def modifieImage(request,id):
    if admin_check_session(request):
        try: 
            if request.method == "POST":
                img = Image.objects.get(id= id) 
                img.title = request.POST.get('titleInput') #
                img.year = datetime.strptime(request.POST.get('yearInput'),'%Y').date() #
                img.artiste = request.POST.get('artisteInput') # 
                img.description = request.POST.get('descriptionInput') #
                img.image = request.FILES["imageInput"] #
                img.save() 
                return redirect('/admin?option=updated')
        except Exception as e: 
            print(e)
            return redirect('/admin?option=updated&error')


    return redirect('/admin')

def deleteImage(request,id):
    if admin_check_session(request):
        try:
            img=Image.objects.get(id=id)
            img.delete()
            return redirect('/admin?option=deleted')
        except:
            pass
    return redirect('/admin?option=deleted&error')



def ajouter_Art(request):
    if admin_check_session(request):
        try: 
            if request.method == "POST": 
                title = request.POST.get('titleInput') #
                year = datetime.strptime(request.POST.get('yearInput'),'%Y').date() #
                artiste = request.POST.get('artisteInput') # 
                description = request.POST.get('descriptionInput') #
                image = request.FILES["imageInput"] #
                img = Image(title = title,year = year , artiste = artiste , description = description , image = image)
                img.save()
                 
                return redirect('/admin/add_art?option=added')
        except Exception as e: 
            print(e)
            return redirect('/admin/add_art?option=added&error')


    return redirect('/admin')

def admin_search(request):
    if admin_check_session(request):
        try:
            if request.method == "GET":
                q = request.GET.get('q')
                images=Image.objects.filter(Q(title__contains=q) | Q(year__contains=q) | Q(artiste__contains=q) | Q(description__contains=q) )
                if images and (q!='' and q!=' '):
                    return render(request,'administrator/index.html',{"images":images})
        except Exception as e: 
            print(e) 
            pass
        return redirect("/admin")
    return render(request,'administrator/login.html')

def about_site(request):
    return render(request,'administrator/Sailor/about.html',{'page':"about"})
    
    
    
    
    


    

def index_site(request):
    return render(request,'administrator/Sailor/index.html',{'page':"index"})
        
def service_site(request):
    return render(request,'administrator/Sailor/services.html',{'page':"services"})
    
def team_site(request):
    return render(request,'administrator/Sailor/team.html',{'page':"team"})
    
def testimonials_site(request):
    return render(request,'administrator/Sailor/testimonials.html',{'page':"testimonials"})

def portfolio_site(request):
    return render(request,'administrator/Sailor/portfolio.html',{'page':"portfolio"})
    
def contact_site(request):
    return render(request,'administrator/Sailor/contact.html',{'page':"contact"})
    