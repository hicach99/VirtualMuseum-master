"""museum URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', views.admin_panel),
    path('about/', views.about_site),
    path('team/', views.team_site),
     path('', views.index_site),
     path('', views.index_site),
     path('services/', views.service_site),
    path('testimonials/', views.testimonials_site),
    path('offres', views.portfolio_site),
    path('admin/login', views.admin_login),
    path('contact', views.contact_site),
    
    
     
    
     
   
    
    
    
    
    
    
    path('admin/logout', views.admin_logout),
    path('admin/add_art', views.admin_add_art),
    path('admin/search',views.admin_search),
    path('admin/arts/add',views.ajouter_Art),
    path('admin/arts/update/<int:id>',views.modifieImage),
    path('admin/arts/delete/<int:id>',views.deleteImage),
    path('admin/assistant', views.admin_assistant),
    path('admin/assistant/keywords/add', views.admin_assistant_keywords_add),
    path('admin/assistant/values/add', views.admin_assistant_values_add),
    path('admin/assistant/relations/add', views.admin_assistant_relations_add),
    path('admin/assistant/keywords/delete/<int:id>', views.admin_assistant_keywords_delete),
    path('admin/assistant/values/delete/<int:id>', views.admin_assistant_values_delete),
    path('admin/assistant/relations/delete/<int:id>', views.admin_assistant_relations_delete),
    path('admin/data/assistant&username=<str:username>&password=<str:password>', views.getAssistantData),
    path('admin/data/images&username=<str:username>&password=<str:password>', views.getImagesData),
    path('start',views.start),
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)